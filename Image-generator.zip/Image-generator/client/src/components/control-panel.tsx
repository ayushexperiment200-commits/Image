import { useState } from "react";
import { Settings, Expand, Palette, Sliders, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface GenerationSettings {
  model: string;
  width: number;
  height: number;
  seed?: string;
  enhancement: string;
  artStyle: string;
}

interface ControlPanelProps {
  settings: GenerationSettings;
  onSettingsChange: (settings: GenerationSettings) => void;
  onGenerate: () => void;
  isGenerating: boolean;
}

export default function ControlPanel({ settings, onSettingsChange, onGenerate, isGenerating }: ControlPanelProps) {
  const [selectedDimension, setSelectedDimension] = useState("1024x1024");

  const updateSettings = (updates: Partial<GenerationSettings>) => {
    onSettingsChange({ ...settings, ...updates });
  };

  const setDimensions = (size: string) => {
    const [width, height] = size.split('x').map(Number);
    setSelectedDimension(size);
    updateSettings({ width, height });
  };

  const dimensionPresets = [
    { size: "1024x1024", label: "Square", icon: "⬜" },
    { size: "1024x768", label: "Landscape", icon: "▭" },
    { size: "768x1024", label: "Portrait", icon: "▬" },
    { size: "1920x1080", label: "Widescreen", icon: "▬" }
  ];

  const artStyles = [
    "photorealistic",
    "digital-art",
    "oil-painting", 
    "watercolor",
    "sketch",
    "anime"
  ];

  return (
    <div className="space-y-6">
      {/* Model Selection */}
      <div className="glass-effect rounded-xl p-6">
        <h3 className="text-lg font-semibold mb-4">
          <Settings className="w-5 h-5 inline mr-2" />
          AI Model
        </h3>
        <Select value={settings.model} onValueChange={(value) => updateSettings({ model: value })}>
          <SelectTrigger className="w-full bg-input border-border" data-testid="select-model">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="flux">Flux (Recommended)</SelectItem>
            <SelectItem value="stable-diffusion">Stable Diffusion</SelectItem>
            <SelectItem value="turbo">Turbo (Fast)</SelectItem>
          </SelectContent>
        </Select>
        <p className="text-xs text-muted-foreground mt-2">
          Flux provides the highest quality results
        </p>
      </div>

      {/* Dimensions */}
      <div className="glass-effect rounded-xl p-6">
        <h3 className="text-lg font-semibold mb-4">
          <Expand className="w-5 h-5 inline mr-2" />
          Dimensions
        </h3>
        <div className="grid grid-cols-2 gap-3 mb-4">
          {dimensionPresets.map(({ size, label, icon }) => (
            <Button
              key={size}
              variant={selectedDimension === size ? "default" : "secondary"}
              className={`aspect-square h-auto flex flex-col items-center justify-center p-3 ${
                selectedDimension === size ? "bg-primary text-primary-foreground" : "bg-muted hover:bg-muted/80"
              }`}
              onClick={() => setDimensions(size)}
              data-testid={`button-dimension-${label.toLowerCase()}`}
            >
              <span className="text-lg mb-1">{icon}</span>
              <span className="text-xs">{label}</span>
            </Button>
          ))}
        </div>
        <div className="flex space-x-2">
          <Input
            type="number"
            placeholder="Width"
            value={settings.width}
            onChange={(e) => updateSettings({ width: parseInt(e.target.value) || 1024 })}
            className="bg-input border-border"
            data-testid="input-width"
          />
          <span className="self-center text-muted-foreground">×</span>
          <Input
            type="number"
            placeholder="Height"
            value={settings.height}
            onChange={(e) => updateSettings({ height: parseInt(e.target.value) || 1024 })}
            className="bg-input border-border"
            data-testid="input-height"
          />
        </div>
      </div>

      {/* Art Styles */}
      <div className="glass-effect rounded-xl p-6">
        <h3 className="text-lg font-semibold mb-4">
          <Palette className="w-5 h-5 inline mr-2" />
          Art Style
        </h3>
        <div className="grid grid-cols-2 gap-2">
          {artStyles.map((style) => (
            <Button
              key={style}
              variant={settings.artStyle === style ? "default" : "secondary"}
              className={`text-sm ${
                settings.artStyle === style ? "bg-primary text-primary-foreground" : "bg-muted hover:bg-muted/80"
              }`}
              onClick={() => updateSettings({ artStyle: style })}
              data-testid={`button-style-${style}`}
            >
              {style.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase())}
            </Button>
          ))}
        </div>
      </div>

      {/* Generate Button */}
      <Button
        className="w-full btn-gradient text-primary-foreground py-6 rounded-xl font-semibold text-lg shadow-lg"
        onClick={onGenerate}
        disabled={isGenerating}
        data-testid="button-generate"
      >
        {isGenerating ? (
          <>
            <Settings className="w-5 h-5 mr-2 animate-spin" />
            Generating...
          </>
        ) : (
          <>
            <Sparkles className="w-5 h-5 mr-2" />
            Generate Image
          </>
        )}
      </Button>

      {/* Advanced Options */}
      <div className="glass-effect rounded-xl p-6">
        <h3 className="text-lg font-semibold mb-4">
          <Sliders className="w-5 h-5 inline mr-2" />
          Advanced
        </h3>
        <div className="space-y-4">
          <div>
            <Label htmlFor="seed" className="text-sm font-medium mb-2 block">
              Seed (Optional)
            </Label>
            <Input
              id="seed"
              type="number"
              placeholder="Random seed for reproducible results"
              value={settings.seed || ""}
              onChange={(e) => updateSettings({ seed: e.target.value })}
              className="bg-input border-border"
              data-testid="input-seed"
            />
          </div>
          <div>
            <Label htmlFor="enhancement" className="text-sm font-medium mb-2 block">
              Enhancement
            </Label>
            <Select value={settings.enhancement} onValueChange={(value) => updateSettings({ enhancement: value })}>
              <SelectTrigger className="bg-input border-border" data-testid="select-enhancement">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">None</SelectItem>
                <SelectItem value="face">Face Enhancement</SelectItem>
                <SelectItem value="sharpen">Sharpen</SelectItem>
                <SelectItem value="upscale">Upscale</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>
    </div>
  );
}
