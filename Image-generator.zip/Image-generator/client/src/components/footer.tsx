export default function Footer() {
  return (
    <footer className="relative border-t border-neon-cyan/30 bg-gradient-to-br from-gray-900/90 to-black/90 backdrop-blur-lg mt-20 overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0 opacity-20 pointer-events-none">
        <div className="absolute top-0 left-0 w-full h-0.5 bg-gradient-to-r from-transparent via-neon-cyan to-transparent animate-scan-line"></div>
        <div className="absolute top-2 right-16 w-2 h-2 bg-neon-purple rounded-full animate-neon-pulse"></div>
        <div className="absolute bottom-3 left-20 w-1.5 h-1.5 bg-neon-magenta rounded-full animate-float"></div>
        <div className="absolute top-3 left-1/3 w-1 h-1 bg-neon-cyan rounded-full animate-float-slow"></div>
        
        {/* Tech grid pattern */}
        <div 
          className="absolute inset-0 opacity-10" 
          style={{
            backgroundImage: `
              linear-gradient(var(--neon-cyan) 1px, transparent 1px),
              linear-gradient(90deg, var(--neon-cyan) 1px, transparent 1px)
            `,
            backgroundSize: '50px 50px'
          }}
        ></div>
      </div>

      <div className="relative container mx-auto px-4 py-12">
        {/* Status indicators */}
        <div className="absolute top-4 right-4 flex flex-col space-y-1">
          <div className="flex items-center space-x-2 text-xs text-neon-cyan font-mono">
            <div className="w-1.5 h-1.5 bg-neon-cyan rounded-full animate-pulse"></div>
            <span>ONLINE</span>
          </div>
          <div className="flex items-center space-x-2 text-xs text-neon-green font-mono">
            <div className="w-1.5 h-1.5 bg-neon-green rounded-full animate-pulse" style={{ animationDelay: '0.5s' }}></div>
            <span>SECURE</span>
          </div>
        </div>

        <div className="text-center">
          {/* Enhanced main text */}
          <div className="mb-6">
            <div className="text-lg text-muted-foreground mb-2 font-light">
              Powered by{" "}
              <a 
                href="https://pollinations.ai/" 
                className="relative inline-block text-neon-cyan hover:text-white transition-all duration-300 font-semibold group"
                target="_blank"
                rel="noopener noreferrer"
                data-testid="link-pollinations"
              >
                <span className="relative z-10">Pollinations.AI</span>
                <div className="absolute inset-0 bg-neon-cyan/20 blur-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded"></div>
                <div className="absolute bottom-0 left-0 w-0 h-0.5 bg-gradient-to-r from-neon-cyan to-neon-purple group-hover:w-full transition-all duration-300"></div>
              </a>
            </div>
            <div className="flex items-center justify-center space-x-4 text-sm text-muted-foreground font-mono">
              <div className="flex items-center space-x-2">
                <div className="w-2 h-0.5 bg-neon-cyan animate-shimmer"></div>
                <span>FREE</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-0.5 bg-neon-purple animate-shimmer" style={{ animationDelay: '0.5s' }}></div>
                <span>UNLIMITED</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-0.5 bg-neon-magenta animate-shimmer" style={{ animationDelay: '1s' }}></div>
                <span>AI GENERATION</span>
              </div>
            </div>
          </div>

          {/* Enhanced navigation links */}
          <div className="flex justify-center space-x-8 text-sm">
            {[
              { href: "#", text: "Privacy Policy", testId: "link-privacy", color: "neon-cyan" },
              { href: "#", text: "Terms", testId: "link-terms", color: "neon-purple" },
              { href: "#", text: "API Docs", testId: "link-api-docs", color: "neon-magenta" },
              { href: "#", text: "Support", testId: "link-support", color: "neon-green" }
            ].map(({ href, text, testId, color }) => (
              <a 
                key={testId}
                href={href} 
                className={`relative group text-muted-foreground hover:text-${color} transition-all duration-300 font-medium tracking-wide`}
                data-testid={testId}
              >
                <span className="relative z-10">{text}</span>
                <div className={`absolute inset-0 bg-${color}/20 blur-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded`}></div>
                <div className={`absolute bottom-0 left-0 w-0 h-0.5 bg-gradient-to-r from-${color} to-transparent group-hover:w-full transition-all duration-300`}></div>
                {/* Corner brackets */}
                <div className={`absolute -top-0.5 -left-0.5 w-1 h-1 border-l border-t border-${color} opacity-0 group-hover:opacity-100 transition-opacity duration-300`}></div>
                <div className={`absolute -bottom-0.5 -right-0.5 w-1 h-1 border-r border-b border-${color} opacity-0 group-hover:opacity-100 transition-opacity duration-300`}></div>
              </a>
            ))}
          </div>
        </div>

        {/* Bottom scan line */}
        <div className="absolute bottom-0 left-0 w-full h-0.5 bg-gradient-to-r from-transparent via-neon-purple to-transparent opacity-40"></div>
        
        {/* Corner elements */}
        <div className="absolute bottom-0 left-0 w-6 h-6 border-l-2 border-b-2 border-neon-cyan/50"></div>
        <div className="absolute bottom-0 right-0 w-6 h-6 border-r-2 border-b-2 border-neon-purple/50"></div>
      </div>
    </footer>
  );
}
