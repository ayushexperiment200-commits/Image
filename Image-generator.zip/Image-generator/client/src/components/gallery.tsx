import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Images, Download, Trash2, Grid, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useLocalStorage } from "@/hooks/use-local-storage";
import { type GeneratedImage } from "@shared/schema";

export default function Gallery() {
  const queryClient = useQueryClient();
  const [localImages] = useLocalStorage<GeneratedImage[]>("generated-images", []);

  const { data: images = [], isLoading } = useQuery<GeneratedImage[]>({
    queryKey: ["/api/images"],
    refetchInterval: false,
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/images/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/images"] });
      toast({
        title: "Image deleted",
        description: "The image has been removed from your gallery.",
      });
    },
    onError: (error) => {
      console.error("Delete failed:", error);
      toast({
        title: "Delete failed",
        description: "Could not delete the image. Please try again.",
        variant: "destructive"
      });
    }
  });

  const handleDownload = (imageUrl: string, prompt: string) => {
    const link = document.createElement('a');
    link.href = imageUrl;
    link.download = `${prompt.slice(0, 30).replace(/[^a-zA-Z0-9]/g, '-')}-${Date.now()}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleDelete = (id: string) => {
    if (confirm("Are you sure you want to delete this image?")) {
      deleteMutation.mutate(id);
    }
  };

  const formatTimeAgo = (date: Date | string) => {
    const now = new Date();
    const then = new Date(date);
    const diffMs = now.getTime() - then.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    
    if (diffMins < 1) return "Just now";
    if (diffMins < 60) return `${diffMins} min ago`;
    if (diffMins < 1440) return `${Math.floor(diffMins / 60)} hr ago`;
    return `${Math.floor(diffMins / 1440)} days ago`;
  };

  // Combine server and local images, removing duplicates
  const allImages = [...images, ...localImages.filter((local: GeneratedImage) => 
    !images.some(server => server.imageUrl === local.imageUrl)
  )];

  if (isLoading) {
    return (
      <div id="gallery" className="mt-16">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-3xl font-bold">
            <Images className="w-8 h-8 inline mr-3" />
            Recent Creations
          </h2>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="glass-effect rounded-xl overflow-hidden animate-pulse">
              <div className="aspect-square bg-muted"></div>
              <div className="p-4">
                <div className="h-4 bg-muted rounded mb-2"></div>
                <div className="h-3 bg-muted rounded w-20"></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div id="gallery" className="mt-16">
      <div className="flex items-center justify-between mb-8">
        <h2 className="text-3xl font-bold">
          <Images className="w-8 h-8 inline mr-3" />
          Recent Creations
        </h2>
        <Button variant="secondary" size="sm" className="bg-muted text-muted-foreground hover:bg-muted/80">
          <Grid className="w-4 h-4 mr-2" />
          View All
        </Button>
      </div>

      {allImages.length === 0 ? (
        <div className="text-center py-12">
          <Images className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-xl font-semibold mb-2">No images yet</h3>
          <p className="text-muted-foreground">
            Generate your first AI image to see it appear here!
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {allImages.slice(0, 12).map((image, index) => (
            <div key={image.id || index} className="image-card glass-effect rounded-xl overflow-hidden">
              <img
                src={image.imageUrl}
                alt={`Generated image: ${image.prompt}`}
                className="w-full aspect-square object-cover"
                loading="lazy"
                data-testid={`img-gallery-${index}`}
              />
              <div className="p-4">
                <p className="text-sm text-muted-foreground truncate" title={image.prompt}>
                  {image.prompt}
                </p>
                <div className="flex items-center justify-between mt-2">
                  <span className="text-xs text-muted-foreground flex items-center">
                    <Clock className="w-3 h-3 mr-1" />
                    {image.createdAt ? formatTimeAgo(image.createdAt) : "Recently"}
                  </span>
                  <div className="flex space-x-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-6 w-6 p-0 text-muted-foreground hover:text-accent"
                      onClick={() => handleDownload(image.imageUrl, image.prompt)}
                      data-testid={`button-download-${index}`}
                    >
                      <Download className="w-3 h-3" />
                    </Button>
                    {image.id && (
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-6 w-6 p-0 text-muted-foreground hover:text-destructive"
                        onClick={() => handleDelete(image.id!)}
                        disabled={deleteMutation.isPending}
                        data-testid={`button-delete-${index}`}
                      >
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
