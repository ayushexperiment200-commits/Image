import { Github, Menu, Zap, Code2, Cpu } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Header() {
  return (
    <header className="relative border-b border-border bg-card/30 backdrop-blur-xl sticky top-0 z-50 overflow-hidden">
      {/* Animated Background Effects */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-0 left-0 w-full h-0.5 bg-gradient-to-r from-transparent via-neon-cyan to-transparent animate-scan-line"></div>
        <div className="absolute top-2 right-10 w-2 h-2 bg-neon-cyan rounded-full animate-neon-pulse"></div>
        <div className="absolute bottom-1 left-20 w-1 h-1 bg-neon-purple rounded-full animate-float"></div>
        <div className="absolute top-1 left-1/3 w-1.5 h-1.5 bg-neon-magenta rounded-full animate-float-slow"></div>
      </div>

      <div className="relative container mx-auto px-4 py-4 flex items-center justify-between">
        {/* Holographic Logo */}
        <div className="flex items-center space-x-3 group">
          <div className="relative w-10 h-10 bg-gradient-to-br from-primary via-secondary to-accent rounded-xl flex items-center justify-center overflow-hidden transition-all duration-300 hover:scale-110 animate-cyber-glow">
            {/* Holographic overlay */}
            <div className="absolute inset-0 bg-gradient-to-r from-neon-cyan/20 to-neon-purple/20 animate-holographic-rotate opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            <Zap className="w-5 h-5 text-primary-foreground relative z-10 animate-float" />
            {/* Scan line effect */}
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent animate-shimmer opacity-0 group-hover:opacity-100"></div>
          </div>
          
          <h1 className="text-xl font-bold holographic-text animate-holographic-text relative">
            <span className="relative z-10">ImageCrafter</span>
            {/* Glitch effect overlay */}
            <span className="absolute inset-0 text-neon-cyan opacity-0 group-hover:opacity-30 animate-digital-glitch">ImageCrafter</span>
          </h1>
          
          {/* Tech indicators */}
          <div className="hidden lg:flex items-center space-x-1 opacity-60">
            <Code2 className="w-3 h-3 text-neon-cyan animate-pulse" />
            <Cpu className="w-3 h-3 text-neon-purple animate-pulse" style={{ animationDelay: '0.5s' }} />
          </div>
        </div>

        {/* Futuristic Navigation */}
        <nav className="hidden md:flex items-center space-x-8">
          <a 
            href="#gallery" 
            className="relative group text-muted-foreground hover:text-neon-cyan transition-all duration-300 font-medium tracking-wide"
            data-testid="link-gallery"
          >
            <span className="relative z-10">Gallery</span>
            {/* Hover glow effect */}
            <div className="absolute inset-0 bg-neon-cyan/20 blur-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded"></div>
            {/* Underline animation */}
            <div className="absolute bottom-0 left-0 w-0 h-0.5 bg-gradient-to-r from-neon-cyan to-neon-purple group-hover:w-full transition-all duration-300"></div>
            {/* Corner brackets */}
            <div className="absolute -top-1 -left-1 w-2 h-2 border-l border-t border-neon-cyan opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            <div className="absolute -bottom-1 -right-1 w-2 h-2 border-r border-b border-neon-cyan opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
          </a>
          
          <a 
            href="#about" 
            className="relative group text-muted-foreground hover:text-neon-purple transition-all duration-300 font-medium tracking-wide"
            data-testid="link-about"
          >
            <span className="relative z-10">About</span>
            <div className="absolute inset-0 bg-neon-purple/20 blur-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded"></div>
            <div className="absolute bottom-0 left-0 w-0 h-0.5 bg-gradient-to-r from-neon-purple to-neon-magenta group-hover:w-full transition-all duration-300"></div>
            <div className="absolute -top-1 -left-1 w-2 h-2 border-l border-t border-neon-purple opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            <div className="absolute -bottom-1 -right-1 w-2 h-2 border-r border-b border-neon-purple opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
          </a>
          
          {/* Enhanced GitHub Button */}
          <Button 
            variant="default" 
            size="sm" 
            className="relative btn-gradient group overflow-hidden border border-neon-cyan/50 hover:border-neon-cyan transition-all duration-300"
            data-testid="button-github"
          >
            <Github className="w-4 h-4 mr-2 relative z-10 group-hover:animate-float" />
            <span className="relative z-10">GitHub</span>
            {/* Pulse effect */}
            <div className="absolute inset-0 bg-neon-cyan/20 animate-energy-pulse opacity-0 group-hover:opacity-100"></div>
          </Button>
        </nav>

        {/* Futuristic Mobile Menu Button */}
        <Button 
          variant="ghost" 
          size="sm" 
          className="md:hidden relative group text-muted-foreground hover:text-neon-cyan border border-transparent hover:border-neon-cyan/50 transition-all duration-300"
          data-testid="button-menu"
        >
          <Menu className="w-5 h-5 relative z-10 group-hover:animate-digital-glitch" />
          {/* Corner indicators */}
          <div className="absolute top-0 left-0 w-1 h-1 bg-neon-cyan opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
          <div className="absolute top-0 right-0 w-1 h-1 bg-neon-cyan opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
          <div className="absolute bottom-0 left-0 w-1 h-1 bg-neon-cyan opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
          <div className="absolute bottom-0 right-0 w-1 h-1 bg-neon-cyan opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
        </Button>
      </div>

      {/* Bottom scan line */}
      <div className="absolute bottom-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-neon-purple to-transparent opacity-50"></div>
    </header>
  );
}
