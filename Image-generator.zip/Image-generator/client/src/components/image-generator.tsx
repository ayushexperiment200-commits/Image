import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Download, Save, Image as ImageIcon, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import ControlPanel from "./control-panel";
import { useLocalStorage } from "@/hooks/use-local-storage";

interface GenerationSettings {
  model: string;
  width: number;
  height: number;
  seed?: string;
  enhancement: string;
  artStyle: string;
}

export default function ImageGenerator() {
  const [prompt, setPrompt] = useState("");
  const [generatedImageUrl, setGeneratedImageUrl] = useState<string | null>(null);
  const [settings, setSettings] = useState<GenerationSettings>({
    model: "flux",
    width: 1024,
    height: 1024,
    seed: "",
    enhancement: "none",
    artStyle: "photorealistic"
  });

  const queryClient = useQueryClient();
  const [, setLocalImages] = useLocalStorage<any[]>("generated-images", []);

  const generateMutation = useMutation({
    mutationFn: async (data: { prompt: string } & GenerationSettings) => {
      const response = await apiRequest("POST", "/api/generate", data);
      return response.json();
    },
    onSuccess: (data) => {
      setGeneratedImageUrl(data.imageUrl);
      toast({
        title: "Image generated successfully!",
        description: "Your image is ready for download.",
      });
    },
    onError: (error) => {
      console.error("Generation failed:", error);
      toast({
        title: "Generation failed",
        description: "Please try again with a different prompt.",
        variant: "destructive"
      });
    }
  });

  const saveMutation = useMutation({
    mutationFn: async () => {
      if (!generatedImageUrl) throw new Error("No image to save");
      
      const imageData = {
        prompt,
        imageUrl: generatedImageUrl,
        model: settings.model,
        width: settings.width,
        height: settings.height,
        seed: settings.seed || null,
        enhancement: settings.enhancement,
        artStyle: settings.artStyle
      };

      const response = await apiRequest("POST", "/api/images", imageData);
      return response.json();
    },
    onSuccess: (savedImage) => {
      // Update local storage for offline gallery
      setLocalImages((prev: any[]) => [savedImage, ...prev.slice(0, 19)]);
      
      // Invalidate gallery query to refresh
      queryClient.invalidateQueries({ queryKey: ["/api/images"] });
      
      toast({
        title: "Image saved to gallery!",
        description: "You can view it in the gallery section below.",
      });
    },
    onError: (error) => {
      console.error("Save failed:", error);
      toast({
        title: "Failed to save image",
        description: "Please try again.",
        variant: "destructive"
      });
    }
  });

  const handleGenerate = () => {
    if (!prompt.trim()) {
      toast({
        title: "Prompt required",
        description: "Please enter a description for your image.",
        variant: "destructive"
      });
      return;
    }

    if (prompt.length > 500) {
      toast({
        title: "Prompt too long",
        description: "Please keep your prompt under 500 characters.",
        variant: "destructive"
      });
      return;
    }

    generateMutation.mutate({ prompt: prompt.trim(), ...settings });
  };

  const handleDownload = () => {
    if (!generatedImageUrl) return;
    
    const link = document.createElement('a');
    link.href = generatedImageUrl;
    link.download = `ai-generated-${Date.now()}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const promptSuggestions = [
    "Photorealistic portrait",
    "Fantasy landscape", 
    "Abstract art",
    "Minimalist design"
  ];

  const fillPrompt = (suggestion: string) => {
    const prompts = {
      "Photorealistic portrait": "A photorealistic portrait of a person with dramatic lighting",
      "Fantasy landscape": "A mystical fantasy landscape with magical creatures and floating islands",
      "Abstract art": "An abstract digital art piece with vibrant colors and geometric shapes",
      "Minimalist design": "A clean minimalist design with simple shapes and neutral colors"
    };
    setPrompt(prompts[suggestion as keyof typeof prompts] || suggestion);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      {/* Generation Panel */}
      <div className="lg:col-span-2 space-y-6">
        {/* Prompt Input Section */}
        <div className="glass-effect rounded-xl p-6">
          <label htmlFor="prompt" className="block text-sm font-medium mb-3">
            ✏️ Describe your image
          </label>
          <div className="relative">
            <Textarea
              id="prompt"
              placeholder="A majestic dragon soaring over a cyberpunk city at sunset..."
              className="h-32 cyber-input rounded-lg resize-none focus:ring-2 focus:ring-ring btn-click-effect"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              data-testid="input-prompt"
            />
            <div className={`absolute bottom-3 right-3 text-xs ${
              prompt.length > 450 ? 'text-destructive' : 
              prompt.length > 300 ? 'text-yellow-500' : 
              'text-muted-foreground'
            }`}>
              <span data-testid="text-char-count">{prompt.length}</span>/500
            </div>
          </div>
          
          {/* Prompt Suggestions */}
          <div className="mt-4">
            <p className="text-sm text-muted-foreground mb-2">Try these prompts:</p>
            <div className="flex flex-wrap gap-2">
              {promptSuggestions.map((suggestion) => (
                <Button
                  key={suggestion}
                  variant="secondary"
                  size="sm"
                  className="text-xs bg-muted text-muted-foreground hover:bg-muted/80"
                  onClick={() => fillPrompt(suggestion)}
                  data-testid={`button-suggestion-${suggestion.toLowerCase().replace(' ', '-')}`}
                >
                  {suggestion}
                </Button>
              ))}
            </div>
          </div>
        </div>

        {/* Generated Image Display */}
        <div className="glass-effect rounded-xl p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold">
              <ImageIcon className="w-5 h-5 inline mr-2" />
              Generated Image
            </h3>
            <div className="flex items-center space-x-2">
              <Button
                variant="secondary"
                size="sm"
                disabled={!generatedImageUrl}
                onClick={handleDownload}
                data-testid="button-download"
              >
                <Download className="w-4 h-4 mr-1" />
                Download
              </Button>
              <Button
                variant="default"
                size="sm"
                disabled={!generatedImageUrl || saveMutation.isPending}
                onClick={() => saveMutation.mutate()}
                data-testid="button-save"
              >
                {saveMutation.isPending ? (
                  <Loader2 className="w-4 h-4 mr-1 animate-spin" />
                ) : (
                  <Save className="w-4 h-4 mr-1" />
                )}
                Save
              </Button>
            </div>
          </div>
          
          <div className="relative">
            {/* Default state */}
            {!generateMutation.isPending && !generatedImageUrl && (
              <div className="aspect-square bg-muted rounded-lg flex items-center justify-center border-2 border-dashed border-border">
                <div className="text-center">
                  <ImageIcon className="w-16 h-16 text-muted-foreground mb-2 mx-auto" />
                  <p className="text-muted-foreground" data-testid="text-placeholder">
                    Your generated image will appear here
                  </p>
                </div>
              </div>
            )}
            
            {/* Loading state */}
            {generateMutation.isPending && (
              <div className="aspect-square bg-muted rounded-lg relative overflow-hidden">
                <div className="absolute inset-0 loading-shimmer opacity-50"></div>
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center">
                    <Loader2 className="w-8 h-8 animate-spin text-primary mx-auto mb-3" />
                    <p className="text-muted-foreground" data-testid="text-generating">
                      Generating your image...
                    </p>
                    <p className="text-sm text-muted-foreground mt-1">
                      This usually takes 10-30 seconds
                    </p>
                  </div>
                </div>
              </div>
            )}
            
            {/* Generated image */}
            {generatedImageUrl && !generateMutation.isPending && (
              <div className="relative">
                <img
                  src={generatedImageUrl}
                  alt="Generated AI image"
                  className="w-full rounded-lg shadow-lg"
                  data-testid="img-generated"
                />
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Control Panel */}
      <ControlPanel 
        settings={settings}
        onSettingsChange={setSettings}
        onGenerate={handleGenerate}
        isGenerating={generateMutation.isPending}
      />
    </div>
  );
}
