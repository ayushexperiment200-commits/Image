interface GenerateImageOptions {
  prompt: string;
  model?: string;
  width?: number;
  height?: number;
  seed?: string;
  enhancement?: string;
}

export class PollinationsAPI {
  private static baseUrl = "https://image.pollinations.ai/prompt";

  static generateImageUrl(options: GenerateImageOptions): string {
    const { 
      prompt, 
      model = "flux", 
      width = 1024, 
      height = 1024, 
      seed, 
      enhancement 
    } = options;

    const encodedPrompt = encodeURIComponent(prompt);
    let url = `${this.baseUrl}/${encodedPrompt}?width=${width}&height=${height}&model=${model}`;
    
    if (seed) {
      url += `&seed=${seed}`;
    }
    
    if (enhancement && enhancement !== "none") {
      url += `&enhance=${enhancement}`;
    }

    return url;
  }

  static async generateImage(options: GenerateImageOptions): Promise<string> {
    return this.generateImageUrl(options);
  }

  static async validateImage(url: string): Promise<boolean> {
    try {
      const response = await fetch(url, { method: 'HEAD' });
      return response.ok && (response.headers.get('content-type')?.startsWith('image/') || false);
    } catch {
      return false;
    }
  }
}
