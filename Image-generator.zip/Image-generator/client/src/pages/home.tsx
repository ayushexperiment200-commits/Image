import Header from "@/components/header";
import Footer from "@/components/footer";
import ImageGenerator from "@/components/image-generator";
import Gallery from "@/components/gallery";

export default function Home() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header />
      <main className="relative min-h-screen gradient-bg">
        {/* Futuristic Background Layers */}
        <div className="absolute inset-0 matrix-grid-bg pointer-events-none" />
        <div className="absolute inset-0 floating-shapes pointer-events-none" />
        <div className="absolute inset-0 geometric-orbs pointer-events-none" />
        <div className="absolute inset-0 particle-field pointer-events-none" />
        <div className="absolute inset-0 scan-lines pointer-events-none" />
        
        <div className="relative container mx-auto px-4 py-8">
          {/* Cyberpunk Hero Section */}
          <div className="relative text-center mb-16 py-20">
            {/* Floating UI Elements */}
            <div className="absolute top-0 left-10 w-20 h-20 border border-neon-cyan/30 bg-neon-cyan/5 backdrop-blur-sm animate-float pointer-events-none" 
                 style={{ clipPath: 'polygon(0 0, 100% 20%, 80% 100%, 20% 80%)' }}>
              <div className="absolute top-2 right-2 w-2 h-2 bg-neon-cyan animate-neon-pulse"></div>
            </div>
            
            <div className="absolute top-20 right-16 w-16 h-16 border border-neon-purple/40 bg-neon-purple/5 backdrop-blur-sm animate-float-slow rotate-45 pointer-events-none">
              <div className="absolute inset-2 border border-neon-purple/60 animate-cyber-glow"></div>
            </div>
            
            <div className="absolute bottom-10 left-20 w-12 h-24 border-l-2 border-t-2 border-neon-magenta/50 animate-levitate pointer-events-none">
              <div className="absolute top-0 left-0 w-4 h-1 bg-neon-magenta animate-shimmer"></div>
            </div>
            
            <div className="absolute bottom-5 right-32 w-24 h-12 border-r-2 border-b-2 border-neon-cyan/50 animate-float-dramatic pointer-events-none">
              <div className="absolute bottom-0 right-0 w-1 h-4 bg-neon-cyan animate-shimmer-slow"></div>
            </div>

            {/* Status Indicators */}
            <div className="absolute top-5 right-5 flex flex-col space-y-2">
              <div className="flex items-center space-x-2 text-xs text-neon-cyan font-mono">
                <div className="w-2 h-2 bg-neon-cyan rounded-full animate-neon-pulse"></div>
                <span>SYSTEM: ONLINE</span>
              </div>
              <div className="flex items-center space-x-2 text-xs text-neon-green font-mono">
                <div className="w-2 h-2 bg-neon-green rounded-full animate-pulse"></div>
                <span>AI: READY</span>
              </div>
              <div className="flex items-center space-x-2 text-xs text-neon-purple font-mono">
                <div className="w-2 h-2 bg-neon-purple rounded-full animate-pulse" style={{ animationDelay: '0.5s' }}></div>
                <span>GPU: ACTIVE</span>
              </div>
            </div>

            {/* Main Heading with Advanced Effects */}
            <div className="relative mb-8">
              {/* Glitch overlay */}
              <h1 className="absolute inset-0 text-4xl md:text-7xl font-black mb-4 text-neon-cyan opacity-20 animate-digital-glitch select-none" aria-hidden="true"
                  style={{ textShadow: '2px 0 0 #ff0080' }}>
                CREATE STUNNING IMAGES WITH AI
              </h1>
              
              {/* Main heading */}
              <h1 className="relative text-4xl md:text-7xl font-black mb-4 holographic-text animate-holographic-text tracking-wider">
                <span className="inline-block animate-float" style={{ animationDelay: '0s' }}>CREATE</span>{' '}
                <span className="inline-block animate-float" style={{ animationDelay: '0.2s' }}>STUNNING</span>{' '}
                <span className="inline-block animate-float" style={{ animationDelay: '0.4s' }}>IMAGES</span>{' '}
                <br className="md:hidden" />
                <span className="inline-block animate-float" style={{ animationDelay: '0.6s' }}>WITH</span>{' '}
                <span className="inline-block text-neon-cyan animate-text-glow" style={{ animationDelay: '0.8s' }}>AI</span>
              </h1>
              
              {/* Scan lines effect */}
              <div className="absolute inset-0 pointer-events-none">
                <div className="absolute top-0 left-0 w-full h-0.5 bg-gradient-to-r from-transparent via-neon-cyan to-transparent animate-scan-line opacity-60"></div>
                <div className="absolute bottom-0 left-0 w-full h-0.5 bg-gradient-to-r from-transparent via-neon-purple to-transparent animate-scan-line-slow opacity-40"></div>
              </div>
            </div>

            {/* Enhanced Description */}
            <div className="relative max-w-3xl mx-auto">
              <p className="text-xl md:text-2xl text-muted-foreground mb-4 font-light tracking-wide leading-relaxed">
                <span className="inline-block opacity-90 hover:text-neon-cyan transition-colors duration-300 cursor-default">Generate high-quality images</span>{' '}
                <span className="inline-block opacity-90 hover:text-neon-purple transition-colors duration-300 cursor-default">from text prompts</span>{' '}
                <span className="inline-block opacity-90 hover:text-neon-magenta transition-colors duration-300 cursor-default">using cutting-edge</span>{' '}
                <span className="text-neon-cyan font-semibold animate-pulse">AI models</span>.
              </p>
              
              <div className="flex items-center justify-center space-x-6 text-sm text-muted-foreground font-mono">
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-0.5 bg-neon-cyan animate-shimmer"></div>
                  <span>100% FREE</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-0.5 bg-neon-purple animate-shimmer" style={{ animationDelay: '0.5s' }}></div>
                  <span>NO API KEYS</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-0.5 bg-neon-magenta animate-shimmer" style={{ animationDelay: '1s' }}></div>
                  <span>UNLIMITED</span>
                </div>
              </div>
            </div>

            {/* Data Stream Visualization */}
            <div className="absolute bottom-0 left-0 w-full h-16 overflow-hidden opacity-30">
              <div className="flex items-end h-full space-x-1">
                {Array.from({ length: 50 }).map((_, i) => (
                  <div
                    key={i}
                    className="w-1 bg-gradient-to-t from-neon-cyan to-transparent animate-pulse"
                    style={{
                      height: `${Math.random() * 60 + 20}%`,
                      animationDelay: `${i * 0.1}s`,
                      animationDuration: `${1 + Math.random()}s`
                    }}
                  />
                ))}
              </div>
            </div>

            {/* Corner Brackets */}
            <div className="absolute top-0 left-0 w-8 h-8 border-l-2 border-t-2 border-neon-cyan animate-neon-pulse"></div>
            <div className="absolute top-0 right-0 w-8 h-8 border-r-2 border-t-2 border-neon-cyan animate-neon-pulse"></div>
            <div className="absolute bottom-0 left-0 w-8 h-8 border-l-2 border-b-2 border-neon-purple animate-neon-pulse-slow"></div>
            <div className="absolute bottom-0 right-0 w-8 h-8 border-r-2 border-b-2 border-neon-purple animate-neon-pulse-slow"></div>
          </div>

          {/* Main Content */}
          <ImageGenerator />
          
          {/* Gallery Section */}
          <Gallery />
        </div>
      </main>
      <Footer />
    </div>
  );
}
