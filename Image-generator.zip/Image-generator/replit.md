# ImageCrafter - AI Image Generation Platform

## Overview

ImageCrafter is a modern web application that enables users to generate high-quality images from text prompts using AI models. The platform provides a free, unlimited image generation service powered by Pollinations.AI, featuring an intuitive interface built with React and a robust Express.js backend.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript for type safety and modern development patterns
- **Routing**: Wouter for lightweight client-side routing
- **Styling**: Tailwind CSS with shadcn/ui components for consistent, modern UI design
- **State Management**: TanStack Query (React Query) for server state management and caching
- **Build Tool**: Vite for fast development and optimized production builds
- **Component Library**: Radix UI primitives with custom theming for accessible, composable components

### Backend Architecture
- **Framework**: Express.js with TypeScript for robust server-side functionality
- **API Design**: RESTful endpoints following standard HTTP conventions
- **Data Storage**: Dual storage strategy with in-memory storage for development and PostgreSQL schema preparation
- **Error Handling**: Centralized error middleware with proper HTTP status codes
- **Development Setup**: Hot reload with Vite integration for seamless full-stack development

### Database Schema
- **ORM**: Drizzle ORM for type-safe database operations with PostgreSQL dialect
- **Schema Design**:
  - `users` table: Basic user authentication with username/password
  - `generated_images` table: Comprehensive image metadata storage including prompt, model, dimensions, and generation parameters
- **Migration Strategy**: Structured migration system with automatic schema generation

### Authentication & Security
- **Session Management**: PostgreSQL-backed sessions using connect-pg-simple
- **Data Validation**: Zod schemas for runtime type checking and API validation
- **CORS Configuration**: Properly configured for cross-origin requests

### AI Integration Architecture
- **Image Generation**: Pollinations.AI API integration for free, unlimited image generation
- **Model Support**: Flux model with configurable parameters (dimensions, seed, enhancement, art style)
- **URL Generation**: Dynamic URL construction for direct image access
- **Validation**: Image URL validation to ensure successful generation

### State Management Strategy
- **Client State**: React Query for server state with optimistic updates
- **Local Storage**: Custom hooks for persistent client-side data (generated images history)
- **Form State**: React Hook Form with Zod validation for robust form handling

## External Dependencies

### Core Technologies
- **Database**: PostgreSQL with Neon serverless for production scalability
- **Image Generation**: Pollinations.AI API for free AI image generation
- **Styling**: Tailwind CSS with PostCSS for utility-first styling
- **Fonts**: Google Fonts integration (Inter, DM Sans, Fira Code, Geist Mono)

### Development Tools
- **Type Checking**: TypeScript with strict configuration
- **Build System**: ESBuild for production bundling
- **Development**: tsx for TypeScript execution in development
- **Code Quality**: Comprehensive linting and formatting setup

### UI Components
- **Design System**: shadcn/ui with Radix UI primitives
- **Icons**: Lucide React for consistent iconography
- **Animations**: Class Variance Authority for component variants
- **Utilities**: clsx and tailwind-merge for conditional styling

### Data Management
- **Query Client**: TanStack Query for efficient data fetching and caching
- **Form Handling**: React Hook Form with Hookform Resolvers
- **Date Handling**: date-fns for date manipulation and formatting
- **Validation**: Zod for schema validation across client and server

The architecture prioritizes developer experience with hot reload, type safety, and modern tooling while maintaining production readiness with proper error handling, data validation, and scalable storage solutions.