import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertImageSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get all generated images
  app.get("/api/images", async (req, res) => {
    try {
      const images = await storage.getImages();
      res.json(images);
    } catch (error) {
      console.error("Failed to get images:", error);
      res.status(500).json({ message: "Failed to get images" });
    }
  });

  // Get specific image
  app.get("/api/images/:id", async (req, res) => {
    try {
      const image = await storage.getImageById(req.params.id);
      if (!image) {
        return res.status(404).json({ message: "Image not found" });
      }
      res.json(image);
    } catch (error) {
      console.error("Failed to get image:", error);
      res.status(500).json({ message: "Failed to get image" });
    }
  });

  // Create new generated image record
  app.post("/api/images", async (req, res) => {
    try {
      const validatedData = insertImageSchema.parse(req.body);
      const image = await storage.createImage(validatedData);
      res.status(201).json(image);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      console.error("Failed to create image:", error);
      res.status(500).json({ message: "Failed to create image" });
    }
  });

  // Delete image
  app.delete("/api/images/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteImage(req.params.id);
      if (!deleted) {
        return res.status(404).json({ message: "Image not found" });
      }
      res.status(204).send();
    } catch (error) {
      console.error("Failed to delete image:", error);
      res.status(500).json({ message: "Failed to delete image" });
    }
  });

  // Generate image using Pollinations.AI
  app.post("/api/generate", async (req, res) => {
    try {
      const { prompt, model = "flux", width = 1024, height = 1024, seed, enhancement } = req.body;
      
      if (!prompt) {
        return res.status(400).json({ message: "Prompt is required" });
      }

      // Build Pollinations.AI URL
      const baseUrl = "https://image.pollinations.ai/prompt";
      const encodedPrompt = encodeURIComponent(prompt);
      let imageUrl = `${baseUrl}/${encodedPrompt}?width=${width}&height=${height}&model=${model}`;
      
      if (seed) {
        imageUrl += `&seed=${seed}`;
      }
      
      if (enhancement && enhancement !== "none") {
        imageUrl += `&enhance=${enhancement}`;
      }

      res.json({ imageUrl });
    } catch (error) {
      console.error("Failed to generate image:", error);
      res.status(500).json({ message: "Failed to generate image" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
