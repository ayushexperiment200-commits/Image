import type { Config } from "tailwindcss";

export default {
  darkMode: ["class"],
  content: ["./client/index.html", "./client/src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
      colors: {
        background: "var(--background)",
        foreground: "var(--foreground)",
        card: {
          DEFAULT: "var(--card)",
          foreground: "var(--card-foreground)",
        },
        popover: {
          DEFAULT: "var(--popover)",
          foreground: "var(--popover-foreground)",
        },
        primary: {
          DEFAULT: "var(--primary)",
          foreground: "var(--primary-foreground)",
        },
        secondary: {
          DEFAULT: "var(--secondary)",
          foreground: "var(--secondary-foreground)",
        },
        muted: {
          DEFAULT: "var(--muted)",
          foreground: "var(--muted-foreground)",
        },
        accent: {
          DEFAULT: "var(--accent)",
          foreground: "var(--accent-foreground)",
        },
        destructive: {
          DEFAULT: "var(--destructive)",
          foreground: "var(--destructive-foreground)",
        },
        border: "var(--border)",
        input: "var(--input)",
        ring: "var(--ring)",
        chart: {
          "1": "var(--chart-1)",
          "2": "var(--chart-2)",
          "3": "var(--chart-3)",
          "4": "var(--chart-4)",
          "5": "var(--chart-5)",
        },
        sidebar: {
          DEFAULT: "var(--sidebar-background)",
          foreground: "var(--sidebar-foreground)",
          primary: "var(--sidebar-primary)",
          "primary-foreground": "var(--sidebar-primary-foreground)",
          accent: "var(--sidebar-accent)",
          "accent-foreground": "var(--sidebar-accent-foreground)",
          border: "var(--sidebar-border)",
          ring: "var(--sidebar-ring)",
        },
      },
      fontFamily: {
        sans: ["var(--font-sans)"],
        serif: ["var(--font-serif)"],
        mono: ["var(--font-mono)"],
      },
      keyframes: {
        "accordion-down": {
          from: {
            height: "0",
          },
          to: {
            height: "var(--radix-accordion-content-height)",
          },
        },
        "accordion-up": {
          from: {
            height: "var(--radix-accordion-content-height)",
          },
          to: {
            height: "0",
          },
        },
        // Futuristic Glow Effects
        "neon-pulse": {
          "0%, 100%": {
            "box-shadow": "0 0 5px var(--neon-cyan), 0 0 10px var(--neon-cyan), 0 0 20px var(--neon-cyan)",
          },
          "50%": {
            "box-shadow": "0 0 20px var(--neon-cyan), 0 0 30px var(--neon-cyan), 0 0 40px var(--neon-cyan)",
          },
        },
        "holographic-rotate": {
          "0%": {
            "background-position": "0% 50%",
            transform: "rotate(0deg)",
          },
          "25%": {
            "background-position": "100% 50%",
          },
          "50%": {
            "background-position": "100% 50%",
            transform: "rotate(180deg)",
          },
          "75%": {
            "background-position": "0% 50%",
          },
          "100%": {
            "background-position": "0% 50%",
            transform: "rotate(360deg)",
          },
        },
        "cyber-glow": {
          "0%, 100%": {
            "box-shadow": "0 0 5px var(--neon-purple)",
          },
          "33%": {
            "box-shadow": "0 0 15px var(--neon-cyan), 0 0 25px var(--neon-cyan)",
          },
          "66%": {
            "box-shadow": "0 0 15px var(--neon-magenta), 0 0 25px var(--neon-magenta)",
          },
        },
        // Matrix and Digital Effects
        "matrix-rain": {
          "0%": {
            transform: "translateY(-100%)",
            opacity: "0",
          },
          "10%": {
            opacity: "1",
          },
          "90%": {
            opacity: "1",
          },
          "100%": {
            transform: "translateY(100vh)",
            opacity: "0",
          },
        },
        "digital-glitch": {
          "0%, 100%": {
            transform: "translate(0)",
            filter: "hue-rotate(0deg)",
          },
          "20%": {
            transform: "translate(-2px, 2px)",
            filter: "hue-rotate(90deg)",
          },
          "40%": {
            transform: "translate(-2px, -2px)",
            filter: "hue-rotate(180deg)",
          },
          "60%": {
            transform: "translate(2px, 2px)",
            filter: "hue-rotate(270deg)",
          },
          "80%": {
            transform: "translate(2px, -2px)",
            filter: "hue-rotate(360deg)",
          },
        },
        "scan-line": {
          "0%": {
            transform: "translateX(-100%)",
          },
          "100%": {
            transform: "translateX(100%)",
          },
        },
        // Floating and Levitation Effects
        "float-gentle": {
          "0%, 100%": {
            transform: "translateY(0px)",
          },
          "50%": {
            transform: "translateY(-10px)",
          },
        },
        "float-dramatic": {
          "0%, 100%": {
            transform: "translateY(0px) rotate(0deg)",
          },
          "25%": {
            transform: "translateY(-15px) rotate(1deg)",
          },
          "50%": {
            transform: "translateY(-20px) rotate(0deg)",
          },
          "75%": {
            transform: "translateY(-15px) rotate(-1deg)",
          },
        },
        "levitate": {
          "0%, 100%": {
            transform: "translateY(0px) scale(1)",
          },
          "50%": {
            transform: "translateY(-20px) scale(1.05)",
          },
        },
        // Particle and Energy Effects
        "particle-float": {
          "0%": {
            transform: "translate(0, 0) scale(0)",
            opacity: "0",
          },
          "10%": {
            opacity: "1",
          },
          "90%": {
            opacity: "1",
          },
          "100%": {
            transform: "translate(100px, -100px) scale(1)",
            opacity: "0",
          },
        },
        "energy-pulse": {
          "0%": {
            transform: "scale(1)",
            opacity: "1",
          },
          "50%": {
            transform: "scale(1.2)",
            opacity: "0.7",
          },
          "100%": {
            transform: "scale(1.5)",
            opacity: "0",
          },
        },
        "shimmer-sweep": {
          "0%": {
            "background-position": "-200% 0",
          },
          "100%": {
            "background-position": "200% 0",
          },
        },
        // Text and Typography Effects
        "text-glow": {
          "0%, 100%": {
            "text-shadow": "0 0 5px var(--neon-cyan)",
          },
          "50%": {
            "text-shadow": "0 0 20px var(--neon-cyan), 0 0 30px var(--neon-cyan)",
          },
        },
        "holographic-text": {
          "0%, 100%": {
            "background-position": "0% 50%",
          },
          "50%": {
            "background-position": "100% 50%",
          },
        },
        "typing-cursor": {
          "0%, 50%": {
            opacity: "1",
          },
          "51%, 100%": {
            opacity: "0",
          },
        },
      },
      animation: {
        "accordion-down": "accordion-down 0.2s ease-out",
        "accordion-up": "accordion-up 0.2s ease-out",
        // Glow Animations
        "neon-pulse": "neon-pulse 2s ease-in-out infinite",
        "neon-pulse-slow": "neon-pulse 4s ease-in-out infinite",
        "cyber-glow": "cyber-glow 3s ease-in-out infinite",
        "holographic-rotate": "holographic-rotate 8s linear infinite",
        // Matrix and Digital Animations
        "matrix-rain": "matrix-rain 3s linear infinite",
        "digital-glitch": "digital-glitch 0.3s ease-in-out infinite",
        "scan-line": "scan-line 2s linear infinite",
        "scan-line-slow": "scan-line 4s linear infinite",
        // Float Animations
        "float": "float-gentle 3s ease-in-out infinite",
        "float-slow": "float-gentle 6s ease-in-out infinite",
        "float-dramatic": "float-dramatic 4s ease-in-out infinite",
        "levitate": "levitate 5s ease-in-out infinite",
        // Particle Animations
        "particle-float": "particle-float 4s ease-out infinite",
        "energy-pulse": "energy-pulse 2s ease-out infinite",
        "shimmer": "shimmer-sweep 2s ease-in-out infinite",
        "shimmer-slow": "shimmer-sweep 4s ease-in-out infinite",
        // Text Animations
        "text-glow": "text-glow 2s ease-in-out infinite",
        "holographic-text": "holographic-text 3s ease-in-out infinite",
        "typing": "typing-cursor 1s ease-in-out infinite",
      },
    },
  },
  plugins: [require("tailwindcss-animate"), require("@tailwindcss/typography")],
} satisfies Config;
